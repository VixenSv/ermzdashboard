﻿using FusionCharts.Charts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MultiCharts
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Chart chart1 = new Chart("column2d", "frst", "400", "300", "jsonurl", "data.json");
            Chart chart2 = new Chart("bar2d", "scnd", "400", "300", "jsonurl", "data.json");
            Chart chart3 = new Chart("pie2d", "fourth", "400", "300", "jsonurl", "data.json");
            Chart chart4 = new Chart("doughnut2d", "fifth", "400", "300", "jsonurl", "data.json");
            Chart chart5 = new Chart("msline", "sixth", "500", "400", "jsonurl", "data2.json"); 
            lit1.Text = chart1.Render();
            lit2.Text = chart2.Render();
            lit3.Text = chart3.Render();
            lit4.Text = chart4.Render();
            lit5.Text = chart5.Render();
 

        }
    }
}